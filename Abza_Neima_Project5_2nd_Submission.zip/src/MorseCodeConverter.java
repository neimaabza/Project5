
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MorseCodeConverter {

	private static MorseCodeTree tree = new MorseCodeTree();

	/**
	 * Constructor 
	 */
	public MorseCodeConverter() {
		
	}
	
	/**
	 * returns a string with all the data in the tree in LNR order with an space in between them
	 * Uses the toArrayList method in MorseCodeTree 
	 * @return the data in the tree in LNR order separated by a space.
	 */
	public static String printTree(){
		String result = "";
		for(String str : tree.toArrayList()) {
			result += str + " ";
		}
		return result;
	}
	
	/**
	 * Converts Morse code into English. Each letter is delimited by a space (‘ ‘). Each word is delimited by a ‘/’.
	 * @param code the morse code
	 * @return the English translation
	 */
	public static String convertToEnglish(String code) {
		
		Scanner morseCodeScan, englishletterScan;
		
		String tempString, returnString;
		String convertedEnglishString = "";
		
		morseCodeScan = new Scanner(code);
		morseCodeScan.useDelimiter("/");
		
		while(morseCodeScan.hasNext()) {
			englishletterScan = new Scanner(morseCodeScan.next());
			englishletterScan.useDelimiter(" ");
			while(englishletterScan.hasNext())
			{
				tempString = englishletterScan.next();
				returnString = tree.fetch(tempString);
				convertedEnglishString += returnString;
				
			}
			convertedEnglishString += ' ';
		}
		morseCodeScan.close();
		return (convertedEnglishString.trim());
	}
	
	/**
	 * Converts a file of Morse code into English Each letter is delimited by a space (‘ ‘). 
	 * Each word is delimited by a ‘/’.
	 * @param codeFile name of the File that contains Morse Code
	 * @return the English translation of the file
	 * @throws FileNotFoundException
	 */
	public static String convertToEnglish(File codeFile) throws FileNotFoundException{
		
		Scanner sn = new Scanner(codeFile);
		String result = "";
		while(sn.hasNextLine())
		{
			result += sn.nextLine();
		}
		sn.close();
		return convertToEnglish(result);
	}

}