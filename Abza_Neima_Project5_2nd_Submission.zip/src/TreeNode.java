
/**
 * 
 * @author Neima Abza
 *
 * @param <T>
 */
public class TreeNode<T> {
	
	private T data;
	public TreeNode<T> leftChild, rightChild;

	/**
	 * Create a new TreeNode with left and right child set to null and data set to the dataNode
	 * @param dataNode the data to be stored in the TreeNode
	 */
	public TreeNode(T dataNode) {
		this.data = dataNode;
		leftChild = null; 
		rightChild = null;		
	}
	
	/**
	 * used for making deep copies
	 * @param node
	 */
	public TreeNode(TreeNode<T> node) {
		
		this.data = node.getData();
		this.leftChild = node.leftChild;
		this.rightChild = node.rightChild;	
	}
	
	/**
	 * Return the data within this TreeNode
	 * @return the data within the TreeNode
	 */
	public T getData() {
		
		return data;
		
	}
}
